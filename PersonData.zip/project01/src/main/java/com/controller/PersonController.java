package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.PersonEntity;
import com.service.PersonService;

@RestController
@RequestMapping("/api/persons")
public class PersonController {
@Autowired
private PersonService personService;
	// Create a new person
@PostMapping
public ResponseEntity<PersonEntity> createPerson(@RequestBody PersonEntity person) {
    PersonEntity createdPerson = personService.createPerson(person);
    return ResponseEntity.ok(createdPerson);
}
    // Get all persons
    @GetMapping("/get")
    public ResponseEntity<List<PersonEntity>> getAllPersons() {
        List<PersonEntity> persons = personService.getAllPersons();
        return ResponseEntity.ok(persons);
    }

    // Get person by ID
    @GetMapping("/{id}")
    public ResponseEntity<ArrayList> getPersonById(@PathVariable int id) {
        ArrayList person = personService.getPersonById(id);
        if (person != null) {
            return ResponseEntity.ok(person);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<PersonEntity> updatePerson(@PathVariable int id, @RequestBody PersonEntity person) {
        PersonEntity updatedPerson = personService.updatePerson(id, person);
        if (updatedPerson != null) {
            return ResponseEntity.ok(updatedPerson);
        } else {
            return ResponseEntity.notFound().build(); // Handle person not found case
        }
    }

    // Delete person by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePerson(@PathVariable int id) {
        personService.deletePerson(id);
        return ResponseEntity.noContent().build();
    }
}
