package com.openfeign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.entity.JobEntity;



@FeignClient(url="http://localhost:8089/api/jobs",value="project02")
public interface IOpenfeign {
	@GetMapping("/{jid}")
public ResponseEntity<JobEntity> getJobById(@PathVariable int jid) ;
        
}
