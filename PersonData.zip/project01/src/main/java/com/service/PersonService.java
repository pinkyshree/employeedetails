package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.JobEntity;
import com.entity.PersonEntity;
import com.openfeign.IOpenfeign;
import com.repository.PersonRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class PersonService {
	@Autowired
	private IOpenfeign openFeign;
    @Autowired
    private PersonRepository personRepository;

    public List<PersonEntity> getAllPersons() {
        return personRepository.findAll();
    }
    public PersonEntity createPerson(PersonEntity person) {
        return personRepository.save(person);
    }

    @CircuitBreaker(name="project01",fallbackMethod = "displaydefaultcompanyinfo")
    public ArrayList getPersonById(int id) {
        PersonEntity person= personRepository.findById(id).get();
//    person= {
//    	        "id": 54,
//    	        "name": "Priya Singh",
//    	        "address": "55 Lajpat Nagar, New Delhi",
//    	        "age": 26,
//    	        "jobid": 4
//    }
       int Jobid= person.getJobid();
       //logic to connect with job class
   JobEntity jobb =openFeign.getJobById(Jobid).getBody();
       ArrayList compinedop=new ArrayList();
       compinedop.add(person);
       compinedop.add(jobb);
        return compinedop; // Return null if the person is not found
  
    }
    public ArrayList displaydefaultcompanyinfo(int id,Exception ex)
    {
    	PersonEntity person= personRepository.findById(id).get();
//      person= {
//      	        "id": 54,
//      	        "name": "Priya Singh",
//      	        "address": "55 Lajpat Nagar, New Delhi",
//      	        "age": 26,
//      	        "jobid": 4
//      }
       //  int Jobid= person.getJobid();
         //logic to connect with job class
   //  JobEntity jobb =openFeign.getJobById(Jobid).getBody();
         com.dto.JobDTO jobdto=new com.dto.JobDTO();
         jobdto.setJid(77776);
         jobdto.setDesignation("Java Developer");
         jobdto.setCompany("TCS");
         ArrayList compinedop=new ArrayList();
         compinedop.add(person);
         compinedop.add(jobdto);
          return compinedop; 
    	
    }
   /* public ArrayList getPersonById(int id) {
        PersonEntity person= personRepository.findById(id).get();
//    person= {
//    	        "id": 54,
//    	        "name": "Priya Singh",
//    	        "address": "55 Lajpat Nagar, New Delhi",
//    	        "age": 26,
//    	        "jobid": 4
//    }
       int Jobid= person.getJobid();
       //logic to connect with job class
   JobEntity jobb =openFeign.getJobById(Jobid).getBody();
       ArrayList compinedop=new ArrayList();
       compinedop.add(person);
       compinedop.add(jobb);
        return compinedop; // Return null if the person is not found
  
    }*/

 // Update person by ID
    public PersonEntity updatePerson(int id, PersonEntity personDetails) {
        PersonEntity existingPerson = personRepository.findById(id).orElse(null);

        if (existingPerson == null) {
            return null; // Handle person not found case
        }

        // Update the fields
        existingPerson.setName(personDetails.getName());
        existingPerson.setAddress(personDetails.getAddress());
        existingPerson.setAge(personDetails.getAge());
        existingPerson.setJobid(personDetails.getJobid());

        // Save the updated entity
        return personRepository.save(existingPerson);
    }
   
	public void deletePerson(int id) {
		// TODO Auto-generated method stub
		 personRepository.deleteById(id);
	}
}
