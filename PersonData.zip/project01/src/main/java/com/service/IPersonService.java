package com.service;

import java.util.List;

import com.entity.PersonEntity;

public interface IPersonService {
	List<PersonEntity> getAllPersons();

    PersonEntity getPersonById(int id);

    PersonEntity savePerson(PersonEntity person);

    void deletePersonById(int id);
}
