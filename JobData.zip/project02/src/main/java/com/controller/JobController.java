package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.JobEntity;
import com.service.JobService;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @Autowired
    private JobService jobService;

    @GetMapping("/get")
    public List<JobEntity> getAllJobs() {
        return jobService.getAllJobs();
    }

    @GetMapping("/{jid}")
    public ResponseEntity<JobEntity> getJobById(@PathVariable int jid) {
        JobEntity job = jobService.getJobById(jid);
        if (job != null) {
            return new ResponseEntity<>(job, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/create")
    public JobEntity createJob(@RequestBody JobEntity job) {
        return jobService.saveJob(job);
    }

    @PutMapping("/{jid}")
    public ResponseEntity<JobEntity> updateJob(@PathVariable int jid, @RequestBody JobEntity jobDetails) {
        JobEntity job = jobService.getJobById(jid);
        if (job != null) {
            job.setDesignation(jobDetails.getDesignation());
            job.setCompany(jobDetails.getCompany());
            JobEntity updatedJob = jobService.saveJob(job);
            return new ResponseEntity<>(updatedJob, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{jid}")
    public ResponseEntity<Void> deleteJob(@PathVariable int jid) {
        jobService.deleteJobById(jid);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
