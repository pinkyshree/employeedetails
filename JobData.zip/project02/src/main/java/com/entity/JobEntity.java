package com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class JobEntity {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int jid;
private String designation;
private String company;
public int getJid() {
	return jid;
}
public void setJid(int jid) {
	this.jid = jid;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public JobEntity(int jid, String designation, String company) {
	super();
	this.jid = jid;
	this.designation = designation;
	this.company = company;
}
public JobEntity() {
	super();
	// TODO Auto-generated constructor stub
}


}
