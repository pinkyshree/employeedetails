package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.JobEntity;

@Repository
public interface IJobRepository extends JpaRepository<JobEntity, Integer> {
}