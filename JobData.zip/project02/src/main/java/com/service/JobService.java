package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.JobEntity;
import com.repository.IJobRepository;
@Service
public class JobService implements IJob{

    @Autowired
    private IJobRepository jobRepository;

    @Override
    public List<JobEntity> getAllJobs() {
        return jobRepository.findAll();
    }

    @Override
    public JobEntity getJobById(int jid) {
        return jobRepository.findById(jid).orElse(null);
    }

    @Override
    public JobEntity saveJob(JobEntity job) {
        return jobRepository.save(job);
    }

    @Override
    public void deleteJobById(int jid) {
        jobRepository.deleteById(jid);
    }
}

