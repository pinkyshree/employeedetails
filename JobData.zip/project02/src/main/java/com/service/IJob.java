package com.service;

import java.util.List;

import com.entity.JobEntity;

public interface IJob {
	List<JobEntity> getAllJobs();

    JobEntity getJobById(int jid);

    JobEntity saveJob(JobEntity job);

    void deleteJobById(int jid);
}
